# hallcross-legal-website
HallCross Legal Website for Nicholas Hallasso
